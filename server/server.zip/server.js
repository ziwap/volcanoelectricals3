const express = require("express");
const app = express();
const mysql = require("mysql");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const saltRounds = 10;
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
const dotenv = require("dotenv");

const httpServer = require("http").createServer(app);
const options = {
  cors: {
    origin: "http://localhost:3011",
    methods: ["GET", "POST"],
  },
};
const io = require("socket.io")(httpServer, options);

app.listen(5000, () => {});

httpServer.listen(7000);

//sokets connection

io.on("connection", (socket) => {
  socket.on("hello", (arg) => {
    console.log(arg); // world
  });
});
//sokets connection

// get config vars
dotenv.config();
const MySQLEvents = require("@rodrigogs/mysql-events");

const db = mysql.createConnection({
  host: "127.0.0.1",
  user: "blinrbun_blinq",
  password: "MarvinTana2011@",
  database: "volcanoelectricals",
});

const program = async () => {
  const instance = new MySQLEvents(db, {
    startAtEnd: true,
    excludedSchemas: {
      mysql: true,
    },
  });

  await instance.start();

  instance.addTrigger({
    name: "TEST",
    expression: "volcanoelectricals.*",
    statement: MySQLEvents.STATEMENTS.ALL,
    onEvent: (event) => {
    
      io.sockets.emit("update", event.timestamp);
      if (event.type == "INSERT" && event.table == "sales") {
        event.affectedRows.map((x) => {
          var sqlproductquantity = `UPDATE product SET units_in_stock = units_in_stock - "${x.after.quantity}"  WHERE product_id = "${x.after.product_id}"`;

          db.query(sqlproductquantity, {}, (err, result) => {
            if (err) {
              throw err;
            } else {
              console.log("update made")
            }
          });
        });
      }
    },
  });

  instance.on(MySQLEvents.EVENTS.CONNECTION_ERROR, console.error);
  instance.on(MySQLEvents.EVENTS.ZONGJI_ERROR, console.error);
};

program()
  .then(() => console.log("Waiting for database events..."))
  .catch(console.error);
app.post("/getuser", (req, res) => {
  db.query(
    "SELECT * FROM user WHERE email ='" + req.body.email + "'",
    {},
    (err, result) => {
      if (err) {
        throw err;
      } else {
        const hash = bcrypt.hashSync(req.body.password, saltRounds);

        if (bcrypt.compareSync(req.body.password, hash)) {
          var returneddata = result[0];
          var token = jwt.sign(
            {
              email: req.body.email,
              password: req.body.password,
              first_name: returneddata.first_name,
              second_name: returneddata.second_name,
              phone_number: returneddata.phone_number,
              user_role_id: returneddata.user_role_id,
              user_designation_id: returneddata.user_designation_id,
              user_id: returneddata.user_id,
            },
            process.env.TOKEN_SECRET,
            { expiresIn: "365d" }
          );

          res.send({
            api_token: token,
            email: req.body.email,
            first_name: returneddata.first_name,
            second_name: returneddata.second_name,
            phone_number: returneddata.phone_number,
            user_role_id: returneddata.user_role_id,
            user_designation_id: returneddata.user_designation_id,
            user_pic: returneddata.user_pic,
            user_id: returneddata.user_id,
          });
        } else {
          throw err;
        }
      }
    }
  );
});

app.post("/verify_token", (req, res) => {
  const token = req.body.api_token;
  if (token) {
    const decode = jwt.verify(token, process.env.TOKEN_SECRET);

    //  Return response with decode data
    res.json(decode);
  } else {
    // Return response with error
    res.json({
      data: "error",
    });
  }
});

app.post("/register", (req, res) => {
  const hash = bcrypt.hashSync(req.body.password, saltRounds);
  var first_name = req.body.first_name;
  var second_name = req.body.second_name;
  var email = req.body.email;
  var password = hash;
  var phone_number = req.body.phone_number;
  var rolesid = 2;
  var designation = 1;
  var username = req.body.first_name + req.body.second_name;

  var sql = `INSERT INTO user (user_name, first_name, second_name, email, password, phone_number, user_role_id, user_designation_id, timecreated) VALUES ("${username}","${first_name}", "${second_name}", "${email}", "${password}", "${phone_number}", "${rolesid}", "${designation}", NOW())`;
  var sqlcount =
    "SELECT COUNT(*) AS recordCount FROM user WHERE email ='" + email + "'";
  db.query(sqlcount, {}, (err, result) => {
    if (err || result[0].recordCount > 0) {
      throw err;
    } else {
      db.query(sql, {}, (err, result) => {
        if (err) {
          throw err;
        } else {
          var token = jwt.sign(
            {
              email: email,
              password: password,
              first_name: first_name,
              second_name: second_name,
              phone_number: phone_number,
              user_role_id: rolesid,
              user_designation_id: designation,
            },
            process.env.TOKEN_SECRET,
            { expiresIn: "365d" }
          );

          res.send({
            api_token: token,
            email: req.body.email,
            first_name: req.body.first_name,
            second_name: req.body.second_name,
            phone_number: req.body.phone_number,
            user_role_id: rolesid,
            user_designation_id: designation,
            user_name: username,
          });
        }
      });
    }
  });
});

//get salesinvoices
app.post("/salesinvoices", (req, res) => {
  db.query(
    "SELECT * FROM sales_invoice WHERE user_id ='" + req.body.user_id + "'",
    {},
    (err, result) => {
      if (err) {
        throw err;
      } else {
        res.send(result);
      }
    }
  );
});

//get salesinvoices

//get sales
app.post("/sales", (req, res) => {
  db.query(
    "SELECT * FROM sales INNER JOIN product ON sales.product_id = product.product_id AND sales.user_id ='" +
      req.body.user_id +
      "'",
    {},
    (err, result) => {
      if (err) {
        throw err;
      } else {
        res.send(result);
      }
    }
  );
});

//get sales

//get roles
app.post("/userroles", (req, res) => {
  db.query(
    "SELECT * FROM user_role  WHERE user_role_id ='" +
      req.body.user_role_id +
      "'",
    {},
    (err, result) => {
      if (err) {
        throw err;
      } else {
        res.send(result[0]);
      }
    }
  );
});

//get roles
//get products
app.get("/products", (req, res) => {
  db.query("SELECT * FROM product", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get products

//get payment_type

app.get("/payment_type", (req, res) => {
  db.query("SELECT * FROM payment_type", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get payment_type

//get products_unit
app.get("/products_unit", (req, res) => {
  db.query("SELECT * FROM product_unit", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get products

//get products_category
app.get("/products_category", (req, res) => {
  db.query("SELECT * FROM product_category", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get products_category

//get payment_type
app.get("/payment_type", (req, res) => {
  db.query("SELECT * FROM payment_type", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get payment_type

//get customer
app.get("/customer", (req, res) => {
  db.query("SELECT * FROM customer", {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      res.send(result);
    }
  });
});

//get customer

//post products

//post products

app.post("/addproducts", (req, res) => {
  var products = req.body;
  console.log(req.body);

  db.query(
    "INSERT INTO product (product_id, product_name, units_in_stock, unit_buying_price, discount_percentage, reorder_level, user_id, product_category_id, product_unit_id,unit_selling_price, product_description) VALUES ?",
    [
      products.map((item) => [
        item.product_id,
        item.product_name,
        item.units_in_stock,
        item.unit_buying_price,
        item.discount_percentage,
        item.reorder_level,
        item.user_id,
        item.product_category_id,
        item.product_unit_id,
        item.unit_selling_price,
        item.product_description,
      ]),
    ],
    (error, result) => {
      if (error) {
        throw error;
      } else {
        res.send("success");
      }
    }
  );
});

//post invoice and sales

app.post("/invoice_sales", (req, res) => {
  //invoice
  var invoice_id = req.body.invoice_id;
  var total_amount = req.body.total_amount;
  var amount_tendered = req.body.amount_tendered;

  var user_id = req.body.user_id;
  var customer_id = req.body.customer_id;
  var payment_type_id = req.body.payment_type_id;
  var status = "Paid";
  //sales

  var salesentries = req.body.salesentries;

  var sqlinvoice = `INSERT INTO sales_invoice (invoice_id, total_amount, amount_tendered, date_recorded, user_id, customer_id, payment_type_id, status) 
  VALUES ("${invoice_id}","${total_amount}", "${amount_tendered}", NOW(), "${user_id}", "${customer_id}", "${payment_type_id}", "${status}")`;
  //UPDATE `volcanoelectricals`.`product` SET `units_in_stock` = '21' WHERE (`product_id` = '1');

  db.query(sqlinvoice, {}, (err, result) => {
    if (err) {
      throw err;
    } else {
      db.query(
        "INSERT INTO sales (quantity, unit_price, sub_total, product_id, user_id, sales_invoice_id) VALUES ?",
        [
          salesentries.map((item) => [
            item.quantity,
            item.unit_price,
            item.sub_total,
            item.product_id,
            item.user_id,
            item.sales_invoice_id,
          ]),
        ],
        (error, result) => {
          if (error) {
            throw error;
          } else {
            res.send("success");
          }
        }
      );
    }
  });
});

//post invoice and sales
